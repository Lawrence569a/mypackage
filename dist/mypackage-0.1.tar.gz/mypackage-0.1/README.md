# mypackage
This library was created as an example

# How to install
Instructions here